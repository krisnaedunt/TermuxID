#!/bin/bash
while true
do
python3 visit.py -p +6289677897716 -c ltc 
sleep 5
python3 visit.py -p +6289677897716 -c doge
done