python visit.py -p +1585437 -c doge &&
python visit.py -p +15187695 -c doge &&
python visit.py -p +19293020 -c doge &&
python visit.py -p +151836974 -c doge &&
python visit.py -p +15856255 -c doge

