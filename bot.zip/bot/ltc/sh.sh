#!/bin/bash
while true
do
python3 bot.py +6289677897716 &
sleep 5;
done
